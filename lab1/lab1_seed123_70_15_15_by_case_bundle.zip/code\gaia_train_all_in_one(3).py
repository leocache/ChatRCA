#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from xgboost import XGBClassifier

try:
    import fasttext as ft_official  # type: ignore
except Exception:
    ft_official = None

try:
    from gensim.models import FastText as GensimFastText  # type: ignore[import-untyped]
except Exception:
    GensimFastText = None  # type: ignore[assignment]


# -----------------------------
# Parsing utilities
# -----------------------------

def normalize_label(label: str) -> str:
    if label is None:
        return "unknown"
    label = str(label).strip()
    label = re.sub(r"^[\[(\{]+|[\])\}]+$", "", label)
    label = label.replace("_", " ").replace("-", " ")
    label = re.sub(r"\s+", " ", label).strip().lower()
    return label or "unknown"


def safe_slug(text: str) -> str:
    text = normalize_label(text)
    return re.sub(r"[^a-z0-9]+", "_", text).strip("_") or "unknown"


def parse_groundtruth_txt(path: str | Path) -> pd.DataFrame:
    records: List[Dict[str, str]] = []
    current: Dict[str, str] = {}
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue
            if line.lower().startswith("ground truth record"):
                if current:
                    records.append(current)
                    current = {}
                current["record_header"] = line
                continue
            if ":" in line:
                k, v = line.split(":", 1)
                current[k.strip()] = v.strip()
        if current:
            records.append(current)

    if not records:
        raise ValueError(f"No records parsed from groundtruth file: {path}")

    df = pd.DataFrame(records)
    for col in ["st_time", "ed_time"]:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce")
    if "anomaly_type" in df.columns:
        df["anomaly_type"] = df["anomaly_type"].map(normalize_label)
    else:
        df["anomaly_type"] = "unknown"
    if "data_type" not in df.columns:
        df["data_type"] = "train"
    else:
        df["data_type"] = df["data_type"].astype(str).str.strip().str.lower()
    if "instance" not in df.columns:
        df["instance"] = ""
    if "service" not in df.columns:
        df["service"] = ""
    return df


def detect_time_column(df: pd.DataFrame, candidates: Iterable[str]) -> Optional[str]:
    lower_map = {c.lower(): c for c in df.columns}
    for cand in candidates:
        if cand.lower() in lower_map:
            return lower_map[cand.lower()]
    for c in df.columns:
        cl = c.lower()
        if any(tok in cl for tok in ["time", "date", "timestamp"]):
            return c
    return None


def discover_gaia_fault_dirs(gaia_dir: str | Path) -> List[Path]:
    """Return sorted F_* subdirectories under gaia_dir (GAIA fault case folders)."""
    root = Path(gaia_dir)
    if not root.is_dir():
        raise ValueError(f"GAIA directory does not exist or is not a directory: {root}")
    dirs = [p for p in root.iterdir() if p.is_dir() and re.match(r"^F_\d+$", p.name, re.I)]
    return sorted(dirs, key=lambda p: int(p.name.split("_", 1)[1]))


def metric_file_stem(path: Path) -> str:
    """Strip one or more trailing .csv suffixes (e.g. docker_x_pct.csv.csv -> docker_x_pct)."""
    s = path.name
    while s.lower().endswith(".csv"):
        s = s[:-4]
    return s


def coerce_metric_time_series(df: pd.DataFrame, time_col: str) -> pd.Series:
    """Parse metric time: human-readable datetimes; numeric timestamp as Unix seconds."""
    s = df[time_col]
    cl = time_col.lower()
    num = pd.to_numeric(s, errors="coerce")
    if cl == "timestamp" and num.notna().sum() > len(s) * 0.5:
        if num.dropna().between(1e9, 1e11).mean() > 0.9:
            return pd.to_datetime(num, unit="s", errors="coerce", utc=False)
    return pd.to_datetime(s, errors="coerce")


def load_log_csv(path: str | Path) -> Tuple[pd.DataFrame, str]:
    df = pd.read_csv(path)
    time_col = detect_time_column(df, ["timestamp", "time", "beijing_time", "datetime"])
    if time_col is None:
        raise ValueError(f"Cannot find time column in log file: {path}")
    df[time_col] = pd.to_datetime(df[time_col], errors="coerce")
    df = df.dropna(subset=[time_col]).copy()
    return df, time_col


def load_trace_csv(path: str | Path) -> Tuple[pd.DataFrame, str]:
    df = pd.read_csv(path)
    time_col = detect_time_column(df, ["beijing_time", "timestamp", "time", "start_time", "datetime"])
    if time_col is None:
        raise ValueError(f"Cannot find time column in trace file: {path}")
    df[time_col] = pd.to_datetime(df[time_col], errors="coerce")
    df = df.dropna(subset=[time_col]).copy()
    return df, time_col


# -----------------------------
# Metric utilities
# -----------------------------

def list_metric_files(metrics_dir: Optional[str | Path]) -> List[Path]:
    """
    Recursively collect every regular file under metrics_dir whose extension is .csv (case-insensitive).
    Includes nested paths such as docker_xxx.csv.csv; no filtering by filename or file size.
    """
    if not metrics_dir:
        return []
    metrics_dir = Path(metrics_dir)
    if not metrics_dir.exists():
        return []
    out: List[Path] = []
    for p in metrics_dir.rglob("*"):
        if not p.is_file():
            continue
        if p.suffix.lower() != ".csv":
            continue
        out.append(p)
    return sorted(out, key=lambda x: str(x))


def merge_metric_file_lists(*lists: List[Path]) -> List[Path]:
    """Concatenate multiple metric file lists, dedupe by resolved path, stable sort by str path."""
    seen: set = set()
    out: List[Path] = []
    for lst in lists:
        for p in lst:
            try:
                key = p.resolve()
            except OSError:
                key = p
            if key not in seen:
                seen.add(key)
                out.append(p)
    return sorted(out, key=lambda x: str(x))


def detect_metric_value_columns(df: pd.DataFrame) -> List[str]:
    excluded_keywords = {"time", "date", "timestamp"}
    value_cols = []
    for c in df.columns:
        if re.match(r"^Unnamed", str(c).strip(), re.I):
            continue
        cl = str(c).lower()
        if any(k in cl for k in excluded_keywords):
            continue
        series = pd.to_numeric(df[c], errors="coerce")
        if series.notna().sum() > 0:
            value_cols.append(c)
    return value_cols


def summarize_numeric_series(s: pd.Series, prefix: str) -> Dict[str, float]:
    s = pd.to_numeric(s, errors="coerce").dropna()
    if s.empty:
        return {f"{prefix}__count": 0.0}
    x = np.arange(len(s), dtype=float)
    slope = 0.0
    if len(s) >= 2:
        try:
            slope = float(np.polyfit(x, s.values.astype(float), 1)[0])
        except Exception:
            slope = 0.0
    return {
        f"{prefix}__count": float(len(s)),
        f"{prefix}__mean": float(s.mean()),
        f"{prefix}__max": float(s.max()),
        f"{prefix}__min": float(s.min()),
        f"{prefix}__std": float(s.std(ddof=0)) if len(s) > 1 else 0.0,
        f"{prefix}__p95": float(s.quantile(0.95)),
        f"{prefix}__first": float(s.iloc[0]),
        f"{prefix}__last": float(s.iloc[-1]),
        f"{prefix}__delta": float(s.iloc[-1] - s.iloc[0]),
        f"{prefix}__slope": slope,
    }


def metric_family_from_name(name: str) -> str:
    n = name.lower()
    if "cpu" in n:
        return "cpu"
    if "diskio" in n or "disk" in n:
        return "diskio"
    if "memory" in n or "mem" in n:
        return "memory"
    if "network" in n or "net" in n:
        return "network"
    return "other"


def summarize_metric_file(path: Path, start: pd.Timestamp, end: pd.Timestamp) -> Tuple[Dict[str, float], str]:
    stem_name = metric_file_stem(path)
    metric_name = safe_slug(stem_name)
    metric_family = metric_family_from_name(metric_name)
    try:
        df = pd.read_csv(path)
    except Exception:
        return {f"metric__{metric_family}__{metric_name}__load_failed": 1.0}, f"{metric_name} load_failed"

    time_col = detect_time_column(
        df,
        ["beijing_time", "date", "timestamp", "time", "datetime"],
    )
    if time_col is None:
        return {f"metric__{metric_family}__{metric_name}__missing_time_col": 1.0}, f"{metric_name} missing_time_col"

    df[time_col] = coerce_metric_time_series(df, time_col)
    df = df.dropna(subset=[time_col]).copy()
    if df.empty:
        return {f"metric__{metric_family}__{metric_name}__empty": 1.0}, f"{metric_name} empty"

    w = df[(df[time_col] >= start) & (df[time_col] <= end)].copy()
    if w.empty:
        return {f"metric__{metric_family}__{metric_name}__window_empty": 1.0}, f"{metric_name} no_points_in_window"

    value_cols = detect_metric_value_columns(w)
    if not value_cols:
        return {f"metric__{metric_family}__{metric_name}__no_numeric_values": 1.0}, f"{metric_name} no_numeric_values"

    feats: Dict[str, float] = {}
    text_bits: List[str] = []
    for col in value_cols[:20]:
        prefix = f"metric__{metric_family}__{metric_name}__{safe_slug(str(col))}"
        stats = summarize_numeric_series(w[col], prefix)
        feats.update(stats)
        if stats.get(f"{prefix}__count", 0) > 0:
            mean_v = stats.get(f"{prefix}__mean", 0.0)
            max_v = stats.get(f"{prefix}__max", 0.0)
            slope_v = stats.get(f"{prefix}__slope", 0.0)
            trend = "increasing" if slope_v > 0 else "decreasing" if slope_v < 0 else "stable"
            text_bits.append(f"{metric_family} {metric_name} {safe_slug(str(col))} mean {mean_v:.4f} max {max_v:.4f} {trend}")
    feats[f"metric_family__{metric_family}__files_seen"] = feats.get(f"metric_family__{metric_family}__files_seen", 0.0) + 1.0
    return feats, " ; ".join(text_bits)


# -----------------------------
# Window extraction / features
# -----------------------------

def slice_window(df: pd.DataFrame, time_col: str, start: pd.Timestamp, end: pd.Timestamp) -> pd.DataFrame:
    return df[(df[time_col] >= start) & (df[time_col] <= end)].copy()


def build_log_features(log_df: pd.DataFrame) -> Dict[str, float]:
    feats: Dict[str, float] = {"log__count": float(len(log_df))}
    if log_df.empty:
        return feats

    level_col = None
    for cand in ["log_level", "level", "severity"]:
        if cand in log_df.columns:
            level_col = cand
            break
    if level_col:
        levels = log_df[level_col].astype(str).str.upper().fillna("UNK")
        for k, v in Counter(levels).items():
            feats[f"log_level__{safe_slug(k)}"] = float(v)

    service_col = None
    for cand in ["service_name", "service", "svc"]:
        if cand in log_df.columns:
            service_col = cand
            break
    if service_col:
        # Keep only identity-agnostic service cardinality; avoid service-name leakage.
        feats["log__unique_services"] = float(log_df[service_col].astype(str).nunique())

    if "message" in log_df.columns:
        text = " ".join(log_df["message"].astype(str).tolist()).lower()
        keywords = ["fail", "failure", "error", "timeout", "expired", "invalid", "exception", "refuse", "denied", "redis", "mysql", "db"]
        for kw in keywords:
            feats[f"log_kw__{safe_slug(kw)}"] = float(text.count(kw))
        feats["log_text__char_len"] = float(len(text))
        feats["log_text__token_len"] = float(len(text.split()))
    return feats


def build_trace_features(trace_df: pd.DataFrame) -> Dict[str, float]:
    feats: Dict[str, float] = {"trace__count": float(len(trace_df))}
    if trace_df.empty:
        return feats

    if "status_code" in trace_df.columns:
        sc = pd.to_numeric(trace_df["status_code"], errors="coerce")
        feats["trace__status_ge_400"] = float((sc >= 400).sum())
        feats["trace__status_ge_500"] = float((sc >= 500).sum())
        for code, cnt in Counter(sc.dropna().astype(int)).items():
            feats[f"trace_status__{code}"] = float(cnt)

    service_col = None
    for cand in ["service_name", "service", "svc"]:
        if cand in trace_df.columns:
            service_col = cand
            break
    if service_col:
        # Keep only identity-agnostic service cardinality; avoid service-name leakage.
        feats["trace__unique_services"] = float(trace_df[service_col].astype(str).nunique())

    if "parent_id" in trace_df.columns:
        feats["trace__root_spans"] = float(trace_df["parent_id"].isna().sum())

    # Do not count keywords on trace messages (avoids leaking method/SQL strings); use status_code stats instead.
    return feats


def sanitize_identity_text(text: str) -> str:
    text = str(text)
    patterns = [
        (r"\b(?:\d{1,3}\.){3}\d{1,3}\b", "<ip>"),
        (r"\b(?:[0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}\b", "<mac>"),
        (r"\b[0-9a-fA-F]{8,}(?:-[0-9a-fA-F]{4,})+\b", "<id>"),
        (r"\bts-[a-z0-9-]+\b", "<service>"),
        # Business-style service names: logservice1, webservice2, etc. (match before generic <entity>)
        (r"\b[a-zA-Z0-9_]*service\d*\b", "<svc>"),
        # Method/operation names on login paths: x_login_y, login_query_redis_info, etc.
        (r"\b\w+_login_\w+\b", "<action>"),
        (r"\b\w*login\w*(_[a-z0-9_]+)+\b", "<action>"),
        # Typical calls: pkg.Class.method, mobservice1.mob_info_to_redis
        (r"\b[a-zA-Z_][a-zA-Z0-9_]{0,48}\.[a-zA-Z_][a-zA-Z0-9_.]{0,80}\b", "<call>"),
        (r"\b(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}\b", "<host>"),
        (r"\b[a-z0-9]+(?:-[a-z0-9]+){2,}\b", "<entity>"),
    ]
    for pat, repl in patterns:
        text = re.sub(pat, repl, text, flags=re.I)
    # Full masking: strip business keywords so the model relies more on structure and frequency.
    text = re.sub(
        r"\b(?:login|memory|moving|file|redis|mysql)\b",
        "<keyword>",
        text,
        flags=re.I,
    )
    return re.sub(r"\s+", " ", text).strip()


def serialize_window_text(log_df: pd.DataFrame, trace_df: pd.DataFrame, metric_texts: List[str], row: pd.Series) -> str:
    parts: List[str] = []
    if not log_df.empty:
        msgs = " ".join(log_df.get("message", pd.Series(dtype=str)).astype(str).tolist())
        lvls = " ".join(log_df.get("log_level", pd.Series(dtype=str)).astype(str).tolist()) if "log_level" in log_df.columns else ""
        parts.append(f"logs {lvls} {msgs}")
    if not trace_df.empty:
        msgs = " ".join(trace_df.get("message", pd.Series(dtype=str)).astype(str).tolist())
        status = " ".join(trace_df.get("status_code", pd.Series(dtype=str)).astype(str).tolist()) if "status_code" in trace_df.columns else ""
        parts.append(f"traces status {status} {msgs}")
    if metric_texts:
        parts.append("metrics " + " ; ".join([m for m in metric_texts if m]))
    text = re.sub(r"\s+", " ", " ".join(parts)).strip()
    return sanitize_identity_text(text)


def _stratified_train_test_row_indices(
    index: pd.Index,
    y: pd.Series,
    train_ratio: float,
    seed: int,
) -> Tuple[pd.Index, pd.Index]:
    """Single train/test split (no val). y must be aligned with index."""
    n = len(index)
    if n < 2:
        return index, index[:0]
    ys = y.loc[index]
    stratify = ys if ys.nunique() > 1 and ys.value_counts().min() >= 2 else None
    test_size = max(1, int(round(n * (1 - train_ratio))))
    if test_size >= n:
        test_size = n - 1
    try:
        train_idx, test_idx = train_test_split(
            index, test_size=test_size, random_state=seed, stratify=stratify
        )
    except ValueError:
        train_idx, test_idx = train_test_split(
            index, test_size=test_size, random_state=seed, stratify=None
        )
    return train_idx, test_idx


def _split_by_case(
    out: pd.DataFrame,
    train_ratio: float,
    seed: int,
) -> Optional[pd.Series]:
    """Assign train/test by case_id (whole case stays on one side).
    Returns a Series aligned with out; None if case_id is missing or fewer than 2 cases.
    """
    if "case_id" not in out.columns:
        return None
    cid = out["case_id"].astype(str).str.strip()
    valid_mask = ~cid.eq("") & ~cid.str.lower().isin({"nan", "none"})
    if not valid_mask.all() or bool(valid_mask.empty):
        return None
    u = out.loc[valid_mask].drop_duplicates(subset=["case_id"], keep="first")
    if len(u) < 2:
        return None
    cases = u["case_id"].astype(str).str.strip().tolist()
    ycase = u["anomaly_type"].astype(str).tolist()
    n = len(cases)
    cnt = Counter(ycase)
    stratify = ycase if len(cnt) > 1 and min(cnt.values()) >= 2 else None
    test_size = max(1, int(round(n * (1 - train_ratio))))
    if test_size >= n:
        test_size = n - 1
    try:
        tr_i, _ = train_test_split(
            np.arange(n, dtype=int),
            test_size=test_size,
            random_state=seed,
            stratify=stratify,
        )
    except ValueError:
        tr_i, _ = train_test_split(
            np.arange(n, dtype=int),
            test_size=test_size,
            random_state=seed,
            stratify=None,
        )
    train_c = {cases[i] for i in tr_i}
    return cid.map(lambda c: "train" if str(c).strip() in train_c else "test")


def _split_by_case_train_val_test(
    out: pd.DataFrame,
    train_ratio: float,
    val_ratio: float,
    seed: int,
) -> Optional[pd.Series]:
    """Assign train/val/test by case_id (each case in exactly one split). Proportions follow train_ratio / val_ratio / (1-train_ratio-val_ratio)."""
    if "case_id" not in out.columns:
        return None
    cid = out["case_id"].astype(str).str.strip()
    valid_mask = ~cid.eq("") & ~cid.str.lower().isin({"nan", "none"})
    if not valid_mask.all() or bool(valid_mask.empty):
        return None
    u = out.loc[valid_mask].drop_duplicates(subset=["case_id"], keep="first")
    n = len(u)
    if n < 3:
        return None
    cases = u["case_id"].astype(str).str.strip().tolist()
    ycase = u["anomaly_type"].astype(str).tolist()
    cnt = Counter(ycase)
    stratify = ycase if len(cnt) > 1 and min(cnt.values()) >= 2 else None
    idx = np.arange(n, dtype=int)
    test_size_1 = max(1, int(round(n * (1 - train_ratio))))
    if test_size_1 >= n - 1:
        test_size_1 = max(1, n - 2)
    try:
        tr_i, temp_i = train_test_split(idx, test_size=test_size_1, random_state=seed, stratify=stratify)
    except ValueError:
        tr_i, temp_i = train_test_split(idx, test_size=test_size_1, random_state=seed, stratify=None)
    if len(temp_i) < 2:
        return None
    ycase_temp = [ycase[i] for i in temp_i]
    cnt2 = Counter(ycase_temp)
    strat2 = ycase_temp if len(cnt2) > 1 and min(cnt2.values()) >= 2 else None
    val_share_of_temp = val_ratio / (1 - train_ratio) if (1 - train_ratio) > 1e-9 else 0.5
    test_size_2 = max(1, int(round(len(temp_i) * (1 - val_share_of_temp))))
    if test_size_2 >= len(temp_i):
        test_size_2 = len(temp_i) - 1
    try:
        va_i, te_i = train_test_split(temp_i, test_size=test_size_2, random_state=seed, stratify=strat2)
    except ValueError:
        va_i, te_i = train_test_split(temp_i, test_size=test_size_2, random_state=seed, stratify=None)
    train_c = {cases[i] for i in tr_i}
    val_c = {cases[i] for i in va_i}
    test_c = {cases[i] for i in te_i}

    def _map(c: str) -> str:
        s = str(c).strip()
        if s in train_c:
            return "train"
        if s in val_c:
            return "val"
        if s in test_c:
            return "test"
        return "train"

    return cid.map(_map)


def _split_row_stratified_train_val_test(
    out: pd.DataFrame,
    train_ratio: float,
    val_ratio: float,
    seed: int,
) -> pd.DataFrame:
    """Stratified train/val/test by sample row (same logic as auto when groundtruth has no fixed splits)."""
    out = out.copy()
    n = len(out)
    if n < 3:
        out["split"] = ["train"] * n
        return out
    y = out["anomaly_type"].astype(str)
    stratify = y if y.nunique() > 1 and y.value_counts().min() >= 2 else None
    train_idx, temp_idx = train_test_split(
        out.index, test_size=max(1, int(round(n * (1 - train_ratio)))), random_state=seed, stratify=stratify
    )
    remaining = out.loc[temp_idx]
    if len(remaining) < 2:
        out["split"] = "train"
        out.loc[temp_idx, "split"] = "test"
        return out
    rem_y = remaining["anomaly_type"].astype(str)
    rem_stratify = rem_y if rem_y.nunique() > 1 and rem_y.value_counts().min() >= 2 else None
    val_share_of_temp = val_ratio / (1 - train_ratio) if (1 - train_ratio) > 1e-9 else 0.5
    val_idx, test_idx = train_test_split(
        remaining.index,
        test_size=max(1, int(round(len(remaining) * (1 - val_share_of_temp)))),
        random_state=seed,
        stratify=rem_stratify,
    )
    out["split"] = "train"
    out.loc[val_idx, "split"] = "val"
    out.loc[test_idx, "split"] = "test"
    return out


def ensure_splits(
    df: pd.DataFrame,
    seed: int = 42,
    train_ratio: float = 0.7,
    val_ratio: float = 0.1,
    split_mode: str = "auto",
) -> pd.DataFrame:
    """
    split_mode:
      - auto: use groundtruth data_type if it already has train/test/val; else random split (~70% / val / test per val_ratio).
      - stratified_7_3: train+test only, 7:3. If case_id exists, stratify by case (F_*) so no case spans train/test; else fall back to row-level stratification.
      - stratified_7_3_by_case: same as above when case_id exists (kept for backward compatibility).
      - stratified_70_15_15_by_case: train/val/test with train_ratio/val_ratio/(rest) by case (F_*); if not possible, row-level stratified 3-way split.
    """
    out = df.copy()

    if split_mode == "stratified_70_15_15_by_case":
        case_split = _split_by_case_train_val_test(out, train_ratio=train_ratio, val_ratio=val_ratio, seed=seed)
        if case_split is not None:
            out["split"] = case_split.values
            return out
        return _split_row_stratified_train_val_test(out, train_ratio, val_ratio, seed)

    if split_mode in ("stratified_7_3", "stratified_7_3_by_case"):
        case_split = _split_by_case(out, train_ratio=train_ratio, seed=seed)
        if case_split is not None:
            out["split"] = case_split.values
            return out

        y = out["anomaly_type"].astype(str)
        tr_idx, te_idx = _stratified_train_test_row_indices(out.index, y, train_ratio, seed)
        out["split"] = "train"
        out.loc[te_idx, "split"] = "test"
        return out

    valid_splits = {"train", "test", "val", "valid", "dev"}
    has_any = out["data_type"].astype(str).str.lower().isin(valid_splits).any()
    unique_existing = set(out["data_type"].astype(str).str.lower().unique())
    if has_any and ("test" in unique_existing or "val" in unique_existing or "valid" in unique_existing or "dev" in unique_existing):
        out["split"] = out["data_type"].astype(str).str.lower().replace({"valid": "val", "dev": "val"})
        return out

    n = len(out)
    if n < 3:
        out["split"] = ["train"] * n
        return out

    y = out["anomaly_type"].astype(str)
    stratify = y if y.nunique() > 1 and y.value_counts().min() >= 2 else None

    train_idx, temp_idx = train_test_split(out.index, test_size=max(1, int(round(n * (1 - train_ratio)))), random_state=seed, stratify=stratify)
    remaining = out.loc[temp_idx]
    if len(remaining) < 2:
        out["split"] = "train"
        out.loc[temp_idx, "split"] = "test"
        return out

    rem_y = remaining["anomaly_type"].astype(str)
    rem_stratify = rem_y if rem_y.nunique() > 1 and rem_y.value_counts().min() >= 2 else None
    val_share_of_temp = val_ratio / (1 - train_ratio)
    val_idx, test_idx = train_test_split(remaining.index, test_size=max(1, int(round(len(remaining) * (1 - val_share_of_temp)))), random_state=seed, stratify=rem_stratify)

    out["split"] = "train"
    out.loc[val_idx, "split"] = "val"
    out.loc[test_idx, "split"] = "test"
    return out


def _build_one_sample(
    sample_id: str,
    case_id: str,
    row: pd.Series,
    log_df: pd.DataFrame,
    log_time_col: str,
    trace_df: pd.DataFrame,
    trace_time_col: str,
    metric_files: List[Path],
    pre_seconds: int,
    post_seconds: int,
) -> Tuple[Dict[str, object], Dict[str, object], str, str]:
    st = pd.to_datetime(row["st_time"]) - pd.Timedelta(seconds=pre_seconds)
    ed = pd.to_datetime(row["ed_time"]) + pd.Timedelta(seconds=post_seconds)
    label = normalize_label(row.get("anomaly_type", "unknown"))
    split = str(row.get("split", "train")).strip().lower()
    if split not in {"train", "test", "val"}:
        split = "train"

    lw = slice_window(log_df, log_time_col, st, ed)
    tw = slice_window(trace_df, trace_time_col, st, ed)

    feats: Dict[str, object] = {
        "sample_id": sample_id,
        "case_id": case_id,
        "label": label,
        "label_slug": safe_slug(label),
        "split": split,
        "st_time": st,
        "ed_time": ed,
    }
    feats.update(build_log_features(lw))
    feats.update(build_trace_features(tw))

    metric_texts: List[str] = []
    for mf in metric_files:
        metric_feats, metric_text = summarize_metric_file(mf, st, ed)
        feats.update(metric_feats)
        if metric_text:
            metric_texts.append(metric_text)

    text = serialize_window_text(lw, tw, metric_texts, row)
    manifest_row = {
        "sample_id": feats["sample_id"],
        "case_id": case_id,
        "label": label,
        "split": split,
        "service": row.get("service", ""),
        "instance": row.get("instance", ""),
        "st_time": st,
        "ed_time": ed,
        "log_rows": len(lw),
        "trace_rows": len(tw),
        "metric_files_seen": len(metric_files),
        "text_preview": text[:500],
    }
    ft_line = f"__label__{safe_slug(label)} {text}".strip()
    return feats, manifest_row, ft_line, split


def build_dataset(
    log_path: Optional[str | Path] = None,
    trace_path: Optional[str | Path] = None,
    groundtruth_path: Optional[str | Path] = None,
    metrics_dir: Optional[str | Path] = None,
    output_dir: str | Path = ".",
    gaia_dir: Optional[str | Path] = None,
    pre_seconds: int = 0,
    post_seconds: int = 0,
    seed: int = 42,
    split_mode: str = "auto",
    train_ratio: float = 0.7,
    val_ratio: float = 0.1,
) -> Dict[str, str]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    feature_rows: List[Dict[str, object]] = []
    manifest_rows: List[Dict[str, object]] = []
    ft_lines = {"train": [], "test": [], "val": []}
    all_metric_paths: List[str] = []

    if gaia_dir is not None:
        fault_dirs_all = discover_gaia_fault_dirs(gaia_dir)
        if not fault_dirs_all:
            raise ValueError(f"No F_* fault case folders found under: {gaia_dir}")

        fault_dirs_valid: List[Path] = []
        parsed_parts: List[pd.DataFrame] = []
        for fault_dir in fault_dirs_all:
            gt_path = fault_dir / "groundtruth.txt"
            log_p = fault_dir / "filtered_log.csv"
            trace_p = fault_dir / "filtered_trace.csv"
            if not (gt_path.is_file() and log_p.is_file() and trace_p.is_file()):
                continue
            gt_part = parse_groundtruth_txt(gt_path)
            gt_part["case_id"] = fault_dir.name
            fault_dirs_valid.append(fault_dir)
            parsed_parts.append(gt_part)

        if not fault_dirs_valid:
            raise ValueError(f"No valid fault folders (groundtruth + log + trace) under: {gaia_dir}")

        combined_for_split = pd.concat(parsed_parts, ignore_index=True)
        combined_for_split = ensure_splits(
            combined_for_split,
            seed=seed,
            train_ratio=train_ratio,
            val_ratio=val_ratio,
            split_mode=split_mode,
        )

        pos = 0
        for i, fault_dir in enumerate(fault_dirs_valid):
            n_rows = len(parsed_parts[i])
            gt_df = combined_for_split.iloc[pos : pos + n_rows].copy()
            pos += n_rows

            log_df, log_time_col = load_log_csv(fault_dir / "filtered_log.csv")
            trace_df, trace_time_col = load_trace_csv(fault_dir / "filtered_trace.csv")
            case_metric_files = list_metric_files(fault_dir / "metric")
            if metrics_dir:
                metric_files = merge_metric_file_lists(case_metric_files, list_metric_files(metrics_dir))
            else:
                metric_files = case_metric_files
            all_metric_paths.extend(str(p) for p in metric_files)

            for local_idx, (_, row) in enumerate(gt_df.iterrows()):
                sample_id = f"{fault_dir.name}_{local_idx}"
                case_id = fault_dir.name
                feats, manifest_row, ft_line, split = _build_one_sample(
                    sample_id=sample_id,
                    case_id=case_id,
                    row=row,
                    log_df=log_df,
                    log_time_col=log_time_col,
                    trace_df=trace_df,
                    trace_time_col=trace_time_col,
                    metric_files=metric_files,
                    pre_seconds=pre_seconds,
                    post_seconds=post_seconds,
                )
                feature_rows.append(feats)
                manifest_rows.append(manifest_row)
                ft_lines[split].append(ft_line)
    else:
        if log_path is None or trace_path is None or groundtruth_path is None:
            raise ValueError("Either --gaia_dir or all of --log_csv, --trace_csv, --groundtruth must be provided.")

        gt_df = ensure_splits(
            parse_groundtruth_txt(groundtruth_path),
            seed=seed,
            train_ratio=train_ratio,
            val_ratio=val_ratio,
            split_mode=split_mode,
        )
        log_df, log_time_col = load_log_csv(log_path)
        trace_df, trace_time_col = load_trace_csv(trace_path)
        metric_files = list_metric_files(metrics_dir)
        all_metric_paths = [str(p) for p in metric_files]

        for idx, row in gt_df.iterrows():
            sample_id = f"sample_{idx}"
            feats, manifest_row, ft_line, split = _build_one_sample(
                sample_id=sample_id,
                case_id="",
                row=row,
                log_df=log_df,
                log_time_col=log_time_col,
                trace_df=trace_df,
                trace_time_col=trace_time_col,
                metric_files=metric_files,
                pre_seconds=pre_seconds,
                post_seconds=post_seconds,
            )
            feature_rows.append(feats)
            manifest_rows.append(manifest_row)
            ft_lines[split].append(ft_line)

    feat_df = pd.DataFrame(feature_rows).fillna(0)
    manifest_df = pd.DataFrame(manifest_rows)

    all_feat_path = output_dir / "xgboost_features_all.csv"
    train_feat_path = output_dir / "xgboost_train.csv"
    test_feat_path = output_dir / "xgboost_test.csv"
    val_feat_path = output_dir / "xgboost_val.csv"
    manifest_path = output_dir / "sample_manifest.csv"
    feature_json_path = output_dir / "feature_columns.json"
    ft_train_path = output_dir / "fasttext_train.txt"
    ft_test_path = output_dir / "fasttext_test.txt"
    ft_val_path = output_dir / "fasttext_val.txt"

    feat_df.to_csv(all_feat_path, index=False)
    feat_df[feat_df["split"] == "train"].to_csv(train_feat_path, index=False)
    feat_df[feat_df["split"] == "test"].to_csv(test_feat_path, index=False)
    feat_df[feat_df["split"] == "val"].to_csv(val_feat_path, index=False)
    manifest_df.to_csv(manifest_path, index=False)

    meta_cols = ["sample_id", "case_id", "label", "label_slug", "split", "service", "instance", "st_time", "ed_time"]
    feature_cols = [c for c in feat_df.columns if c not in meta_cols]
    with open(feature_json_path, "w", encoding="utf-8") as f:
        json.dump(
            {"feature_columns": feature_cols, "metric_files": all_metric_paths},
            f,
            ensure_ascii=False,
            indent=2,
        )

    split_config_path = output_dir / "split_config.json"
    with open(split_config_path, "w", encoding="utf-8") as f:
        json.dump(
            {
                "label_source": "groundtruth.anomaly_type (after normalize_label, written to CSV column label)",
                "split_mode": split_mode,
                "train_ratio": train_ratio,
                "val_ratio": val_ratio,
                "seed": seed,
                "split_counts": feat_df["split"].astype(str).value_counts().to_dict(),
                "description": {
                    "stratified_7_3": "If case_id exists, stratify by case (F_*) 7:3; else fall back to row-level stratification.",
                    "stratified_7_3_by_case": "Stratify by case_id (F_*) 7:3; a fault case never appears in both train and test.",
                    "stratified_70_15_15_by_case": "Train/val/test by case_id (F_*) using train_ratio and val_ratio; test share is 1-train_ratio-val_ratio; else row-level 3-way.",
                    "auto": "Use groundtruth train/test/val if present; else random split.",
                }.get(split_mode, ""),
            },
            f,
            ensure_ascii=False,
            indent=2,
        )

    ft_train_path.write_text("\n".join(ft_lines["train"]), encoding="utf-8")
    ft_test_path.write_text("\n".join(ft_lines["test"]), encoding="utf-8")
    ft_val_path.write_text("\n".join(ft_lines["val"]), encoding="utf-8")

    return {
        "xgboost_features_all": str(all_feat_path),
        "xgboost_train": str(train_feat_path),
        "xgboost_test": str(test_feat_path),
        "xgboost_val": str(val_feat_path),
        "fasttext_train": str(ft_train_path),
        "fasttext_test": str(ft_test_path),
        "fasttext_val": str(ft_val_path),
        "sample_manifest": str(manifest_path),
        "feature_columns_json": str(feature_json_path),
        "split_config": str(split_config_path),
    }


# -----------------------------
# Training utilities
# -----------------------------

def evaluate_predictions(y_true: List[str], y_pred: List[str], labels: Optional[List[str]] = None) -> Dict[str, object]:
    if len(y_true) == 0:
        return {"n_samples": 0, "accuracy": None, "macro_f1": None, "weighted_f1": None, "classification_report": {}, "confusion_matrix": []}
    labels = labels or sorted(set(y_true) | set(y_pred))
    return {
        "n_samples": len(y_true),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
        "classification_report": classification_report(y_true, y_pred, labels=labels, output_dict=True, zero_division=0),
        "confusion_matrix_labels": labels,
        "confusion_matrix": confusion_matrix(y_true, y_pred, labels=labels).tolist(),
    }


def train_xgboost(features_csv: str | Path, output_dir: str | Path, seed: int = 42) -> Dict[str, object]:
    output_dir = Path(output_dir)
    df = pd.read_csv(features_csv)
    meta_cols = {"sample_id", "case_id", "label", "label_slug", "split", "service", "instance", "st_time", "ed_time"}
    feature_cols = [c for c in df.columns if c not in meta_cols]
    df[feature_cols] = df[feature_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)

    train_df = df[df["split"] == "train"].copy()
    test_df = df[df["split"] == "test"].copy()
    val_df = df[df["split"] == "val"].copy()
    if test_df.empty:
        test_df = val_df.copy()

    if train_df["label"].nunique() < 2:
        return {"status": "skipped", "reason": "XGBoost requires at least 2 classes in the training split."}

    X_train = train_df[feature_cols].values
    y_train_text = train_df["label"].astype(str).tolist()
    encoder = LabelEncoder()
    y_train = encoder.fit_transform(y_train_text)

    model = XGBClassifier(
        objective="multi:softprob",
        num_class=len(encoder.classes_),
        n_estimators=50,
        max_depth=2,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.5,
        reg_lambda=5.0,
        min_child_weight=3,
        random_state=seed,
        n_jobs=4,
        eval_metric="mlogloss",
    )
    model.fit(X_train, y_train)
    importances = model.feature_importances_
    top_indices = np.argsort(importances)[::-1][:10]
    print("Top 10 features by importance:")
    for idx in top_indices:
        print(f"{feature_cols[idx]}: {importances[idx]}")

    results: Dict[str, object] = {
        "status": "ok",
        "feature_count": len(feature_cols),
        "train_samples": int(len(train_df)),
        "classes": encoder.classes_.tolist(),
        "notes": [
            "Train metrics are evaluated on the same samples used to fit the model and are often optimistic; prefer test metrics.",
            "If train is near 100% but test is much lower, that is typical overfitting; if both are near chance, check features or splits.",
        ],
    }

    for split_name, split_df in [("train", train_df), ("val", val_df), ("test", test_df)]:
        if split_df.empty:
            results[split_name] = {"n_samples": 0}
            continue
        X = split_df[feature_cols].values
        pred_idx = model.predict(X)
        pred_idx = np.asarray(pred_idx)
        # With num_class=2, predict may return an (n, 2) margin/prob matrix instead of class indices
        if pred_idx.ndim > 1:
            pred_idx = np.argmax(model.predict_proba(X), axis=1)
        pred = encoder.inverse_transform(pred_idx)
        gold = split_df["label"].astype(str).tolist()
        # Test may contain labels unseen in training; align labels with gold/pred, not only encoder.classes_
        lab_split = sorted(set(encoder.classes_.tolist()) | set(gold) | set(pred))
        results[split_name] = evaluate_predictions(gold, pred.tolist(), labels=lab_split)

    joblib.dump({"model": model, "label_encoder": encoder, "feature_columns": feature_cols}, output_dir / "xgboost_model.joblib")
    with open(output_dir / "xgboost_metrics.json", "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    return results


def tokenize(text: str) -> List[str]:
    return re.findall(r"[a-zA-Z0-9_\.\-/]+", str(text).lower())


def parse_fasttext_file(path: str | Path) -> Tuple[List[List[str]], List[str], List[str]]:
    texts_tokens: List[List[str]] = []
    raw_texts: List[str] = []
    labels: List[str] = []
    if not Path(path).exists():
        return texts_tokens, raw_texts, labels
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split(maxsplit=1)
            if not parts or not parts[0].startswith("__label__"):
                continue
            label = parts[0].replace("__label__", "", 1)
            text = parts[1] if len(parts) > 1 else ""
            labels.append(label)
            raw_texts.append(text)
            texts_tokens.append(tokenize(text))
    return texts_tokens, raw_texts, labels


def average_embedding(tokens: List[str], model) -> np.ndarray:
    vectors = [model.wv[t] for t in tokens if t in model.wv]
    if not vectors:
        return np.zeros(model.vector_size, dtype=float)
    return np.mean(np.vstack(vectors), axis=0)


def train_fasttext(
    train_txt: str | Path,
    val_txt: str | Path,
    test_txt: str | Path,
    output_dir: str | Path,
    seed: int = 42,
    lr: float = 0.8,
    epoch: int = 5,
    dim: int = 100,
) -> Dict[str, object]:
    output_dir = Path(output_dir)
    train_tokens, train_texts, train_labels = parse_fasttext_file(train_txt)
    val_tokens, val_texts, val_labels = parse_fasttext_file(val_txt)
    test_tokens, test_texts, test_labels = parse_fasttext_file(test_txt)
    if not test_labels and val_labels:
        test_tokens, test_texts, test_labels = val_tokens, val_texts, val_labels

    if len(set(train_labels)) < 2:
        return {"status": "skipped", "reason": "FastText requires at least 2 classes in the training split."}

    # Official fastText, if available
    if ft_official is not None:
        model = ft_official.train_supervised(input=str(train_txt), lr=lr, epoch=epoch, wordNgrams=1, dim=dim, loss="softmax")
        model.save_model(str(output_dir / "fasttext_model.bin"))

        def predict_many(texts: List[str]) -> List[str]:
            preds = []
            for txt in texts:
                labels, _ = model.predict(txt, k=1)
                preds.append(labels[0].replace("__label__", "") if labels else "unknown")
            return preds

        results = {
            "status": "ok",
            "backend": "official_fasttext",
            "notes": [
                "Train metrics are in-sample and often high; val may be empty; prefer test metrics.",
            ],
            "train": evaluate_predictions(train_labels, predict_many(train_texts)),
            "val": evaluate_predictions(val_labels, predict_many(val_texts)) if val_labels else {"n_samples": 0},
            "test": evaluate_predictions(test_labels, predict_many(test_texts)) if test_labels else {"n_samples": 0},
        }
        with open(output_dir / "fasttext_metrics.json", "w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        return results

    # Fallback: gensim FastText embeddings + logistic regression
    if GensimFastText is None:
        return {"status": "skipped", "reason": "Neither official fasttext nor gensim FastText is available."}

    emb_model = GensimFastText(
        vector_size=dim,
        window=5,
        min_count=1,
        workers=1,
        sg=1,
        seed=seed,
    )
    emb_model.build_vocab(corpus_iterable=train_tokens)
    emb_model.train(corpus_iterable=train_tokens, total_examples=len(train_tokens), epochs=epoch)

    X_train = np.vstack([average_embedding(toks, emb_model) for toks in train_tokens])
    clf = LogisticRegression(max_iter=2000, random_state=seed)
    clf.fit(X_train, train_labels)

    def predict_tokenized(tokenized: List[List[str]]) -> List[str]:
        if not tokenized:
            return []
        X = np.vstack([average_embedding(toks, emb_model) for toks in tokenized])
        return clf.predict(X).tolist()

    results = {
        "status": "ok",
        "backend": "gensim_fasttext_plus_logreg",
        "notes": [
            "Train metrics are in-sample and often high; val may be empty; prefer test metrics.",
        ],
        "train": evaluate_predictions(train_labels, predict_tokenized(train_tokens)),
        "val": evaluate_predictions(val_labels, predict_tokenized(val_tokens)) if val_labels else {"n_samples": 0},
        "test": evaluate_predictions(test_labels, predict_tokenized(test_tokens)) if test_labels else {"n_samples": 0},
    }
    joblib.dump({"embedding_model": emb_model, "classifier": clf}, output_dir / "fasttext_fallback.joblib")
    with open(output_dir / "fasttext_metrics.json", "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    return results


# -----------------------------
# CLI
# -----------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="One-click GAIA pipeline: build dataset, train XGBoost, and train FastText.")
    parser.add_argument("--gaia_dir", default=None, help="Root directory with F_* fault folders (filtered_log/trace, groundtruth, metric per folder)")
    parser.add_argument("--log_csv", default=None, help="Path to filtered_log CSV (single-file mode)")
    parser.add_argument("--trace_csv", default=None, help="Path to filtered_trace CSV (single-file mode)")
    parser.add_argument("--groundtruth", default=None, help="Path to groundtruth txt (single-file mode)")
    parser.add_argument(
        "--metrics_dir",
        default=None,
        help="Optional extra directory of metric CSVs (recursive rglob). "
        "In --gaia_dir mode: merged with each F_*/metric (deduped). "
        "In single-file mode: the only metric source.",
    )
    parser.add_argument("--output_dir", required=True, help="Output directory")
    parser.add_argument("--pre_seconds", type=int, default=0, help="Extend window before st_time")
    parser.add_argument("--post_seconds", type=int, default=0, help="Extend window after ed_time")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--split_mode",
        default="stratified_7_3_by_case",
        choices=["auto", "stratified_7_3", "stratified_7_3_by_case", "stratified_70_15_15_by_case"],
        help="Default stratified_7_3_by_case: stratify by fault case F_* 7:3 so a case is not in both train and test (no case-level leakage). "
        "stratified_7_3: same when case_id exists; otherwise falls back to row-level split. "
        "stratified_70_15_15_by_case: train/val/test by case using --train_ratio and --val_ratio (test = 1 - train_ratio - val_ratio). "
        "auto: use groundtruth data_type if test/val are set. Labels always come from groundtruth anomaly_type.",
    )
    parser.add_argument("--train_ratio", type=float, default=0.7, help="Train fraction (test is roughly 1 - train_ratio).")
    parser.add_argument(
        "--val_ratio",
        type=float,
        default=0.1,
        help="When split_mode=auto and splits are not fixed in groundtruth, fraction of the holdout used for val.",
    )
    parser.add_argument("--fasttext_lr", type=float, default=0.8)
    parser.add_argument("--fasttext_epoch", type=int, default=5)
    parser.add_argument("--fasttext_dim", type=int, default=100)
    parser.add_argument(
        "--build_only",
        action="store_true",
        help="Only build features and text (xgboost_*.csv, fasttext_*.txt, sample_manifest, feature_columns.json, etc.); skip training.",
    )
    parser.add_argument(
        "--train_fasttext_only",
        action="store_true",
        help="Run build_dataset then train FastText only (skip XGBoost; compare with an XGBoost-only run separately).",
    )
    args = parser.parse_args()

    if args.build_only and args.train_fasttext_only:
        parser.error("--build_only and --train_fasttext_only cannot be used together")

    if args.gaia_dir is None and (args.log_csv is None or args.trace_csv is None or args.groundtruth is None):
        parser.error("Provide --gaia_dir, or all of --log_csv, --trace_csv, and --groundtruth.")

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    build_outputs = build_dataset(
        log_path=args.log_csv,
        trace_path=args.trace_csv,
        groundtruth_path=args.groundtruth,
        metrics_dir=args.metrics_dir,
        output_dir=output_dir,
        gaia_dir=args.gaia_dir,
        pre_seconds=args.pre_seconds,
        post_seconds=args.post_seconds,
        seed=args.seed,
        split_mode=args.split_mode,
        train_ratio=args.train_ratio,
        val_ratio=args.val_ratio,
    )

    if args.build_only:
        summary = {
            "build_outputs": build_outputs,
            "xgboost": {"status": "skipped", "reason": "--build_only"},
            "fasttext": {"status": "skipped", "reason": "--build_only"},
        }
        with open(output_dir / "run_summary.json", "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return

    if args.train_fasttext_only:
        ft_results = train_fasttext(
            train_txt=build_outputs["fasttext_train"],
            val_txt=build_outputs["fasttext_val"],
            test_txt=build_outputs["fasttext_test"],
            output_dir=output_dir,
            seed=args.seed,
            lr=args.fasttext_lr,
            epoch=args.fasttext_epoch,
            dim=args.fasttext_dim,
        )
        summary = {
            "build_outputs": build_outputs,
            "xgboost": {"status": "skipped", "reason": "--train_fasttext_only"},
            "fasttext": ft_results,
        }
        with open(output_dir / "run_summary.json", "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return

    xgb_results = train_xgboost(build_outputs["xgboost_features_all"], output_dir=output_dir, seed=args.seed)
    ft_results = train_fasttext(
        train_txt=build_outputs["fasttext_train"],
        val_txt=build_outputs["fasttext_val"],
        test_txt=build_outputs["fasttext_test"],
        output_dir=output_dir,
        seed=args.seed,
        lr=args.fasttext_lr,
        epoch=args.fasttext_epoch,
        dim=args.fasttext_dim,
    )

    summary = {
        "build_outputs": build_outputs,
        "xgboost": xgb_results,
        "fasttext": ft_results,
    }
    with open(output_dir / "run_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
